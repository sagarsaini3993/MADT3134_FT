

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

print_r($_SESSION);
}
 ?>


<html>
<head>
  <link rel="stylesheet" type="text/css" href="css/bulma.min.css">
  <style type="text/css">
    .container{
      margin-top:40px;
    }
    form {
      max-width:250px;
    }
    button {
      margin-top:10px;
    }
  </style>
</head>
<body>

  <?php
session_start();
  $name = $_SESSION["name"];

   ?>

<div class="container">
  <div class="content">



    <h1> Welcome, <?php echo "$name"; ?> </h1>

    <h1> Choose a Section </h1>

    <?php

    $dbhost = "localhost";
    $dbuser = "root";
    $dbpassword = "";
    $dbname = "school";

    $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

    $sql = "SELECT * from instructors";
    $results = mysqli_query($conn, $sql);

    if ($results->num_rows > 0) {

    while ($row = $results->fetch_assoc()) {


     ?>

    <p>
      Instructor Name:  <?php echo $row["name"]; ?> <br>
      Spots Remaining:  <?php echo $row["seatsAvailable"]; ?> </br>

      <?php
      if ($row["seatsAvailable"] > 0) {
          ?>

      <a href="enroll3.php?btn=<?php echo $row["id"]; ?>" class="button is-outlined is-link"> Enroll </a>


      <?php
    } else {
      echo "No more seats available";
    }
    ?>

    </p>


    <!-- <p>
      Instructor Name:  Sam Jones <br>
      Spots Remaining:  18 </br>
      <a href="enroll3.php" class="button is-outlined is-link"> Enroll </a>
    </p>


    <p>
      Instructor Name:  Mary Feist <br>
      Spots Remaining:  2 </br>
      <a href="enroll3.php" class="button is-outlined is-link"> Enroll </a>
    </p>

    <p>
      Instructor Name:  Mr. Popular <br>
      Spots Remaining:  0 </br>

    </p> -->

<?php
}
}
 ?>

    <a href="index.php"> Go Back </a>

  </div>
</div>

</body>
</html>
