<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

session_start();


  $str = $_POST["name"];
  $id = $_POST["stuId"];
 // $str."<br>";
 // md5($str, TRUE)."<br>";
 $val = md5($str . '' . $id);

 $_SESSION["name"] = "$str";

 // print_r($_SESSION);


       // 1. UI: GET the information from the form
              $name = $_POST["name"];
              $stuId = $_POST["stuId"];

       // 2. DB: connect to database

       // ----------------------------------------

     	$dbhost = "localhost";
     	$dbuser = "root";
     	$dbpassword = "";
     	$dbname = "school";

     	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

      // $sql = "UPDATE students SET accesskey = '$val' WHERE name='$name' ";
      $sql = "SELECT * from students WHERE name = '$name' AND studentid = '$stuId'";

      // echo $sql;
      $results = mysqli_query($conn, $sql);

      // 4. If successful, redirect user to previous page
      if ($results->num_rows > 0) {
        // header("Location: show-locations.php");
        echo"Success! Your access key is : '$val'   ";
        $sql = "UPDATE students SET accesskey = '$val' WHERE name='$name' ";


      }
      // 5. If failure, show an error message
      else {
         echo "<span style='color:red'> Error - Sorry! You are not in the database. Please contact student services for assistance. </span><br>";
      }

     	$results = mysqli_query($conn, $sql);


  }


 ?>



<html>
<head>
  <link rel="stylesheet" type="text/css" href="css/bulma.min.css">
  <style type="text/css">
    .container{
      margin-top:40px;
    }
    form {
      max-width:250px;
    }
    button {
      margin-top:10px;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="content">

    <h1> Register for an Access Key </h1>

    <form action="getkey.php" method="POST">
      Name:  <input class="input" type="text" name="name" required> <br>
      ID:    <input class="input" type="text" name="stuId" required> <br>

      <button type="submit" class="button is-outlined is-link"> Generate Key </button>

    </form>

    <a href="index.php"> Go Back </a>

  </div>
</div>

</body>
</html>
