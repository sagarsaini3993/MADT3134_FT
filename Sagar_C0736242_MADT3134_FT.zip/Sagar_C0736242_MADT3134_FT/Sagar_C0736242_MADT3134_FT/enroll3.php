
<?php

if ($_SERVER["REQUEST_METHOD"] == "GET") {
  $instructorId =   $_GET["btn"];


session_start();
  $name = $_SESSION["name"];



  $dbhost = "localhost";
  $dbuser = "root";
  $dbpassword = "";
  $dbname = "school";

  $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

  $sql = "SELECT seatsAvailable from instructors WHERE id = '$instructorId'";
  $results = mysqli_query($conn, $sql);

  if ($results->num_rows > 0) {

    while ($row = $results->fetch_assoc()) {

      $str = $row["seatsAvailable"]-1;
      // echo "$str";
      $query =  "UPDATE instructors SET seatsAvailable='$str' WHERE id='$instructorId'";
      // echo "$query";
      $result = mysqli_query($conn, $query);

    }

  } else {
    echo "Error";
  }




  }


 ?>


<html>
<head>
  <link rel="stylesheet" type="text/css" href="css/bulma.min.css">
  <style type="text/css">
    .container{
      margin-top:40px;
    }
    form {
      max-width:250px;
    }
    button {
      margin-top:10px;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="content">

    <h1> Welcome, <?php echo "$name"; ?> </h1>

    <h1> Enrollment Confirmation </h1>

    <p>
      Success! You are enrolled!
    </p>

    <a href="index.php"> Go Back </a>

  </div>
</div>

</body>
</html>
