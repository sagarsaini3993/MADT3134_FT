
<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {

      // 1. UI: GET the information from the form
      $accKey = $_POST["accesskey"];

      // 2. DB: connect to database

      // ----------------------------------------

    	$dbhost = "localhost";
    	$dbuser = "root";
    	$dbpassword = "";
    	$dbname = "school";

    	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

    	// SQL QUERY: 'SELECT * FROM users where username="pritesh" and password="1234"';
      // $query = 'SELECT * FROM users where accesskey="'
      //         . $accKey
      //         . '"';

      $query = "SELECT * from students WHERE accesskey = '$accKey'";

      echo "Query you are sending to db: " . $query  . "<br>";

    	$results = mysqli_query($conn, $query);

      // 3. LOGIC: check if user is in the database
      // If in db, $y = 0
      // Otherwise, $y = 1
      $y = mysqli_num_rows($results);
      echo "Number of rows returned: " . $y . "<br>";

      if ($y == 0) {
          // 4. he is not in the db, so show an error message
          echo "<span style='color:red'> Error - Invalid access key </span><br>";
      }
      else {
          // 5. else, send him to page 2
          header("Location: enroll2.php");
      }

      // ----------------------------------------
  }
?>







<html>
<head>
  <link rel="stylesheet" type="text/css" href="css/bulma.min.css">
  <style type="text/css">
    .container{
      margin-top:40px;
    }
    form {
      max-width:250px;
    }
    button {
      margin-top:10px;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="content">

    <h1> Enter Your Access Key </h1>

    <form action="enroll.php" method="POST">
      Access Key:  <input class="input" type="text" name="accesskey"> <br>
      <button type="submit" class="button is-outlined is-link"> Next </button>
    </form>

    <a href="index.php"> Go Back </a>

  </div>
</div>

</body>
</html>
